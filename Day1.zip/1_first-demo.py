print("Hello World")
print(len("Hello World!"))