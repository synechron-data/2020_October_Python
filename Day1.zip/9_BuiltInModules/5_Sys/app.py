# This module provides access to some variables used or maintained by the
# interpreter and to functions that interact strongly with the interpreter.

import sys

# print(sys.builtin_module_names)
# print(sys.path)
# print(sys.version)
# print(sys.maxsize)

print(sys.argv)
# print("Hello {}, Welcome to {}".format(sys.argv[1], sys.argv[2]))
# py app.py Manish Python_World
